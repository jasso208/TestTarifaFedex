from distutils.core import setup
setup(
name = 'src',
version = '1.0.0',
py_modules = ['src'],
url = 'https://github.com/jasso208/TestTarifaFedex.git',
author = 'Javier Jasso',
author_email = 'jasso.gallegos@gmail.com',
description = 'Test Fedex'
) 