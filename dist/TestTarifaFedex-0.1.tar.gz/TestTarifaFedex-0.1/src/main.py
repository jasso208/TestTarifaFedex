from saludo import Saludo

saludo = Saludo(nombre="Jasso")

print(saludo.saludo_jasso())